import react from "react";
import { Text,View,StyleSheet } from "react-native";


const ListScreen = () => {
    return <Text>This is List Screen</Text>
}


const styles = StyleSheet.create({}); 

export default ListScreen;